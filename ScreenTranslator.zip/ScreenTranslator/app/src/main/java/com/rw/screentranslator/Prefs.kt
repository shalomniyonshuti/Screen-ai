package com.rw.screentranslator

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("key", "").orEmpty().ifBlank { BuildConfig.GEMINI_API_KEY }
        set(v) = sp.edit().putString("key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL }
        set(v) = sp.edit().putString("model", v.trim()).apply()

    var lang: String
        get() = sp.getString("lang", "Kinyarwanda").orEmpty()
        set(v) = sp.edit().putString("lang", v).apply()

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash"
        const val TTS_MODEL = "gemini-2.5-flash-preview-tts"
        val LANGS = linkedMapOf(
            "Kinyarwanda" to "rw",
            "English" to "en",
            "French" to "fr",
            "Swahili" to "sw"
        )
    }
}
