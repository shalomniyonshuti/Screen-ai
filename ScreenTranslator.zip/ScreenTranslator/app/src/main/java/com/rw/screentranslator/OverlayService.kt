package com.rw.screentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.max

class OverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "translator"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var speaker: Speaker

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null

    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var resultView: TextView? = null
    private var langBtn: Button? = null

    private var screenW = 0
    private var screenH = 0
    private var lastTranslation = ""
    private var lastB64 = ""
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        speaker = Speaker(this, prefs)
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (projection == null && data != null) {
            try {
                setupProjection(code, data)
                showBubble()
            } catch (e: Exception) {
                Toast.makeText(this, "Capture setup failed: ${e.message}", Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Screen Translator", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Screen Translator is running")
            .setContentText("Tap the floating Tr button to translate your screen")
            .addAction(android.R.drawable.ic_delete, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- screen capture ----------

    private fun setupProjection(code: Int, data: Intent) {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            screenW = b.width(); screenH = b.height()
        } else {
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels; screenH = dm.heightPixels
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        // Android 14+ requires a callback before creating the virtual display.
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)
        projection = mp
        val r = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        reader = r
        vdisplay = mp.createVirtualDisplay(
            "screen-translator", screenW, screenH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, main
        )
    }

    private fun capture() {
        if (busy) return
        busy = true
        bubble?.visibility = View.INVISIBLE
        panel?.visibility = View.INVISIBLE
        main.postDelayed({ grab(0) }, 300) // let the overlay disappear from the frame
    }

    private fun grab(attempt: Int) {
        val img = try {
            reader?.acquireLatestImage()
        } catch (e: Exception) {
            null
        }
        if (img == null) {
            if (attempt < 5) {
                main.postDelayed({ grab(attempt + 1) }, 200)
            } else {
                restoreUi()
                showPanel()
                setText("Could not capture the screen. Tap the button again.")
                busy = false
            }
            return
        }
        val b64 = toBase64(img)
        restoreUi()
        showPanel()
        lastB64 = b64
        translate()
    }

    private fun translate() {
        setText("Translating to ${prefs.lang}…")
        val b64 = lastB64
        Thread {
            try {
                val t = Gemini.translateScreen(prefs, b64)
                main.post { lastTranslation = t; setText(t); busy = false }
            } catch (e: Exception) {
                main.post { setText("⚠ ${e.message}"); busy = false }
            }
        }.start()
    }

    private fun toBase64(img: Image): String {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * screenW
        val wide = Bitmap.createBitmap(
            screenW + rowPadding / pixelStride, screenH, Bitmap.Config.ARGB_8888
        )
        wide.copyPixelsFromBuffer(plane.buffer)
        img.close()
        val full = Bitmap.createBitmap(wide, 0, 0, screenW, screenH)
        val scale = 1280f / max(screenW, screenH)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(full, (screenW * scale).toInt(), (screenH * scale).toInt(), true)
        } else full
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ---------- overlay UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun restoreUi() {
        bubble?.visibility = View.VISIBLE
        panel?.visibility = View.VISIBLE
    }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "Tr"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE60B6E4F.toInt())
            }
        }
        val size = dp(56)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(220)
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) capture()
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
    }

    private class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
        }
    }

    private fun showPanel() {
        if (panel != null) return
        val svc = this
        val tv = TextView(svc).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        resultView = tv
        val scroll = MaxHeightScroll(svc, (screenH * 0.42f).toInt()).apply { addView(tv) }

        fun btn(label: String, onClick: () -> Unit) = Button(svc).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val lang = btn("→ ${prefs.lang.take(3).uppercase()}") { cycleLanguage() }
        langBtn = lang
        val row = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(btn("Speak") { speak() })
            addView(btn("Sign") { sign() })
            addView(lang)
            addView(btn("Close") { hidePanel() })
        }
        val root = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(0xF2111827.toInt())
            }
            addView(scroll)
            addView(row)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            y = dp(24)
            horizontalMargin = 0.03f
        }
        wm.addView(root, lp)
        panel = root
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        panel = null
        resultView = null
        langBtn = null
    }

    private fun setText(t: String) {
        resultView?.text = t
    }

    private fun cycleLanguage() {
        val names = Prefs.LANGS.keys.toList()
        val next = names[(names.indexOf(prefs.lang) + 1) % names.size]
        prefs.lang = next
        langBtn?.text = "→ ${next.take(3).uppercase()}"
        if (lastB64.isNotEmpty() && !busy) {
            busy = true
            translate()
        } else {
            Toast.makeText(this, "Language: $next", Toast.LENGTH_SHORT).show()
        }
    }

    private fun speak() {
        if (lastTranslation.isBlank()) {
            Toast.makeText(this, "Translate something first", Toast.LENGTH_SHORT).show()
            return
        }
        speaker.speak(lastTranslation) { msg ->
            main.post { Toast.makeText(this, "Voice: $msg", Toast.LENGTH_LONG).show() }
        }
    }

    private fun sign() {
        if (lastTranslation.isBlank()) {
            Toast.makeText(this, "Translate something first", Toast.LENGTH_SHORT).show()
            return
        }
        setText("Preparing sign guide…")
        val t = lastTranslation
        Thread {
            try {
                val g = Gemini.signGuide(prefs, t)
                main.post { setText(g) }
            } catch (e: Exception) {
                main.post { setText("⚠ ${e.message}") }
            }
        }.start()
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bubble = null
        vdisplay?.release()
        reader?.close()
        projection?.stop()
        speaker.shutdown()
        super.onDestroy()
    }
}
