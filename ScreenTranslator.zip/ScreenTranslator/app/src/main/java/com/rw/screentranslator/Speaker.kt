package com.rw.screentranslator

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Speaks with the phone's own voice when it supports the language,
 * otherwise falls back to Gemini text-to-speech (works for Kinyarwanda on most phones).
 */
class Speaker(ctx: Context, private val prefs: Prefs) {
    private var ready = false
    private var track: AudioTrack? = null
    private var tts: TextToSpeech? =
        TextToSpeech(ctx.applicationContext) { status -> ready = status == TextToSpeech.SUCCESS }

    fun speak(text: String, onError: (String) -> Unit) {
        val code = Prefs.LANGS[prefs.lang] ?: "en"
        val t = tts
        if (ready && t != null) {
            val r = t.setLanguage(Locale(code))
            if (r == TextToSpeech.LANG_AVAILABLE ||
                r == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
                r == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE
            ) {
                t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tr")
                return
            }
        }
        Thread {
            try {
                play(Gemini.speech(prefs, text.take(1500)))
            } catch (e: Exception) {
                onError(e.message ?: "Voice failed")
            }
        }.start()
    }

    private fun play(pcm: ByteArray) {
        track?.release()
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t.play()
        track = t
    }

    fun shutdown() {
        tts?.shutdown()
        track?.release()
    }
}
